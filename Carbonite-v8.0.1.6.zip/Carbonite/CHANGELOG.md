7.2 Release
------------
Updated files to latest github release as of June 3rd 2017.