--- **LibMapCompat-1.0** Attempts to restore old map functions to the new bfa mapping system.
-- Data is stored privately within the library but can be accessed through the functions below.

