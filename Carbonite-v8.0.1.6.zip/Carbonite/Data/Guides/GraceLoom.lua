local L = LibStub("AceLocale-3.0"):GetLocale("Carbonite")

Nx.GuideData[L["Grace Loom"]] = {
	["Mode"] = 32,
[680] = "0,40.5,69.5",
}
