local L = LibStub("AceLocale-3.0"):GetLocale("Carbonite")

Nx.GuideData[L["Death Knight Trainer"]] = {
	["Mode"] = 32,
	[124] = "0,51.08,27.57|0,47.48,26.56|0,46.7,31.93",
}
