local L = LibStub("AceLocale-3.0"):GetLocale("Carbonite")

Nx.GuideData[L["Monk Trainer"]] = {
	["Mode"] = 32,
	[84] = "1,68.31,16.21",
	[85] = "2,68.88,40.02,1"
}
