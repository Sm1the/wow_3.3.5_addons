local L = LibStub("AceLocale-3.0"):GetLocale("Carbonite")

Nx.GuideData[L["Transmogrifier"]] = {
	["Mode"] = 32,
	[84] = "1,50.8,60.8",
	[85] = "2,58,65.4,1",
	[625] = "0,39.2,40.9,10"
}
