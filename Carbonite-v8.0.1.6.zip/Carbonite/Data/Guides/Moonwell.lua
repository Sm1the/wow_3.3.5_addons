local L = LibStub("AceLocale-3.0"):GetLocale("Carbonite")

Nx.GuideData[L["Moonwell"]] = {
	["Mode"] = 32,
	[102] = "0,80.32,65.08",
	[105] = "0,62.02,39.21|1,37.26,63.98|1,38.31,64.05"
}
