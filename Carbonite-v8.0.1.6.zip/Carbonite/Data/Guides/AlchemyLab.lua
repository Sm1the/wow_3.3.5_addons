local L = LibStub("AceLocale-3.0"):GetLocale("Carbonite")

Nx.GuideData[L["Alchemy Lab"]] = {
	["Mode"] = 32,
}
