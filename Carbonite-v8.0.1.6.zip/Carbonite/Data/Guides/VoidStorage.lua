local L = LibStub("AceLocale-3.0"):GetLocale("Carbonite")

Nx.GuideData[L["Void Storage"]] = {
	["Mode"] = 32,
	[84] = "1,50.6,60.5",
	[85] = "2,57.9,65.5,1",
}
