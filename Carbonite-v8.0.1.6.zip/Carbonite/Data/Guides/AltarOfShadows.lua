local L = LibStub("AceLocale-3.0"):GetLocale("Carbonite")

Nx.GuideData[L["Altar Of Shadows"]] = {
	["Mode"] = 32,
	[104] = "0,58.29,70.91",
}
