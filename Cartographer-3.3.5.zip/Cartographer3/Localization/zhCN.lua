Cartographer3_L("Main", "zhCN", function() return {
	-- ["English"] = "Localized",
} end)
