Cartographer3_L("Main", "frFR", function() return {
	-- ["English"] = "Localized",
} end)
