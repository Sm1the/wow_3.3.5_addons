﻿if select(6, GetAddOnInfo("Cartographer3_" .. (debugstack():match("[a%.][p%.][h%.]er3\\(.-)\\") or ""))) ~= "MISSING" then return end

if GetLocale() == "ruRU" then
	Cartographer3_InstancePOIs_Localization = {
	["Instance POI"] = "Точки интереса в инстах",
	["Module which adds default POIs to instance maps"] = "Модуль, добавляющий точки интереса в инстах",
		
	}
end