--[[
	OmniCC Localization File
		Russian by StingerSoft
--]]

if GetLocale() == 'ruRU' then
	local L = OMNICC_LOCALS
	L.UpgradeIncompatible = 'Обновлено из несовместимой версии. Загружены стандартные настройки'
	L.Updated = 'Обновлено v%s'
end
