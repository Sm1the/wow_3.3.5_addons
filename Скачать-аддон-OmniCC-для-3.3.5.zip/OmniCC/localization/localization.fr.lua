--[[
	OmniCC Localization File
		French by Mordroba
--]]

if GetLocale() == 'frFR' then
	OMNICC_LOCALS = {}
	local L = OMNICC_LOCALS
	L.UpgradeIncompatible = "Mise \195\160 jour \195\160 partir d'une version incompatible. Param\195\168tres par d\195\169faut charg\195\169s"
	L.Updated = "Updated to v%s"
end