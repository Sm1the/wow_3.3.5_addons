
if GetLocale() == 'koKR' then
	local L = OMNICC_LOCALS
	L.UpgradeIncompatible = "호환되지 않는 버전을 업그레이드 합니다. 기본값으로 불려옵니다."
	L.Updated = "v%s 업데이트"
end