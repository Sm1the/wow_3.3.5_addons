--[[
	OmniCC Localization File
		English (default language)
--]]

OMNICC_LOCALS = {}
local L = OMNICC_LOCALS
L.UpgradeIncompatible = "Upgrading from an incompatible version. Default settings loaded"
L.Updated = "Updated to v%s"