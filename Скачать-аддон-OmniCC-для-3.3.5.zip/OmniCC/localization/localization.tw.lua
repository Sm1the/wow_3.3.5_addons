﻿--[[
	OmniCC Localization File
		T-Chinese by NightOwl
--]]

if GetLocale() == 'zhTW' then
	local L = OMNICC_LOCALS
	L.UpgradeIncompatible = "升級的版本不兼容. 載入預設設定"
	L.Updated = "升級至 v%s"
end
