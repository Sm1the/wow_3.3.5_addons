﻿--[[
	Bagnon Localization file: Spanish
		Credit goes to Ferroginus
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bagnon', 'esES')
if not L then return end