--[[
	Bagnon Localization file: French Language
		Credit goes to namAtsar
--]]

local L = LibStub('AceLocale-3.0'):NewLocale('Bagnon', 'frFR')
if not L then return end