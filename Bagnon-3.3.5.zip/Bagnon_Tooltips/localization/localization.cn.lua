﻿--[[
	Bagnon_Tooltips Localization
		2008-12-01 by yleaf@cwdg(yaroot@gmail.com)
--]]

if GetLocale() ~= "zhCN" then return end

BAGNON_NUM_BAGS = '背包: %d'
BAGNON_NUM_BANK = '银行: %d'
BAGNON_EQUIPPED = '已装备'